import { createFileRoute } from "@tanstack/react-router";
import { AboutView } from "@/components/chai-chip";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [
    { title: "About the Bureau | ChaiChip" },
    { name: "description", content: "Meet ChaiChip's departments of snack geometry, bubble measurement, and unnecessary standards." },
    { property: "og:title", content: "About the Bureau | ChaiChip" },
    { property: "og:description", content: "The official story of the Bureau of Completely Unnecessary Standards." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: AboutView,
});
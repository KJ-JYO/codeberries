import { createFileRoute } from "@tanstack/react-router";
import { ReportsView } from "@/components/chai-chip";

export const Route = createFileRoute("/reports")({
  head: () => ({ meta: [
    { title: "Inspection Reports | ChaiChip" },
    { name: "description", content: "Review saved ChaiChip banana chip and chai bubble inspection reports." },
    { property: "og:title", content: "Inspection Reports | ChaiChip" },
    { property: "og:description", content: "Archived scientifically questionable snack and tea findings." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: ReportsView,
});
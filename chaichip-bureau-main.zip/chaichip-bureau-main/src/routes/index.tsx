import { createFileRoute } from "@tanstack/react-router";
import { Footer, Hero, HowItWorks, InspectionSection, Navbar } from "@/components/chai-chip";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "ChaiChip | Unnecessary Snack Inspection" },
    { name: "description", content: "Inspect banana chip geometry and chai bubbles with scientifically questionable precision." },
    { property: "og:title", content: "ChaiChip | Unnecessary Snack Inspection" },
    { property: "og:description", content: "The Bureau of Completely Unnecessary Standards inspects snacks and tea." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  return <><Navbar /><main><Hero /><InspectionSection /><HowItWorks /></main><Footer /></>;
}

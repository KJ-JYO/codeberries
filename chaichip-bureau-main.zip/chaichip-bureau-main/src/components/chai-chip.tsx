import { Link } from "@tanstack/react-router";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";

import snacksArt from "@/assets/chai-chip-hero-snacks.png";
import bureauArt from "@/assets/chai-chip-bureau.png";
import mascotArt from "@/assets/chai-chip-mascot.png";
import iconSheet from "@/assets/chai-chip-icons.png";

export type Report = {
  id: string;
  type: "Banana Chip" | "Chai";
  date: string;
  thumbnail: string;
  classification: string;
  score: string;
  conclusion: string;
  details?: { label: string; value: string }[];
};

export const REPORTS_KEY = "chaichip-reports";

const readReports = (): Report[] => {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(REPORTS_KEY) ?? "[]") as Report[];
  } catch {
    return [];
  }
};

const saveReport = (report: Report) => {
  try {
    window.localStorage.setItem(REPORTS_KEY, JSON.stringify([report, ...readReports()].slice(0, 24)));
  } catch {
    const withoutImage = { ...report, thumbnail: "" };
    window.localStorage.setItem(REPORTS_KEY, JSON.stringify([withoutImage, ...readReports()].slice(0, 24)));
  }
};

const thumbnailFor = (file: File) =>
  new Promise<string>((resolve) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const scale = Math.min(1, 260 / Math.max(image.width, image.height));
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.68));
    };
    image.onerror = () => resolve("");
    image.src = url;
  });

function PixelButton({ children, onClick, disabled, tone = "dark", type = "button", className = "" }: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  tone?: "dark" | "gold" | "plain";
  type?: "button" | "submit";
  className?: string;
}) {
  const tones = {
    dark: "bg-primary text-primary-foreground border-primary-shadow",
    gold: "bg-accent text-accent-foreground border-accent-shadow",
    plain: "bg-card text-foreground border-border-strong",
  };
  return <button type={type} onClick={onClick} disabled={disabled} className={`pixel-button ${tones[tone]} ${className}`}>{children}</button>;
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="brand-lockup" aria-label="ChaiChip home">
          <img src={mascotArt} alt="" width={816} height={816} className="brand-mascot" />
          <span className="min-w-0"><strong>ChaiChip<span className="brand-spark">✦</span></strong><small>Bureau of Completely Unnecessary Standards™</small></span>
        </Link>
        <button className="menu-button" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-label="Toggle navigation"><span /><span /><span /></button>
        <nav className={open ? "main-nav is-open" : "main-nav"} aria-label="Main navigation">
          <Link to="/" activeOptions={{ exact: true }} onClick={() => setOpen(false)}>Home</Link>
          <Link to="/" hash="inspect" onClick={() => setOpen(false)}>Inspect</Link>
          <Link to="/about" onClick={() => setOpen(false)}>About</Link>
          <Link to="/reports" onClick={() => setOpen(false)}>Reports</Link>
        </nav>
        <div className="accuracy"><span className="pixel-cup" aria-hidden="true">♨</span><span>Not useful.<br />Just accurate.</span></div>
      </div>
    </header>
  );
}

export function Footer() {
  return <footer className="footer"><strong>ChaiChip</strong><span>Bureau of Completely Unnecessary Standards™</span><span className="footer-motto">Snacks. Tea. Standards. (Not Really.)</span></footer>;
}

export function Hero() {
  return (
    <section className="hero-band">
      <div className="hero-scene snacks-scene">
        <p className="scribble snack-note">Banana chips?<br />Let's inspect.<span className="scribble-arrow">↘</span></p>
        <p className="scribble chai-note">Chai?<br />Count the bubbles.<span className="scribble-arrow">↙</span></p>
        <img src={snacksArt} alt="Pixel-art bowl of banana chips and a glass of chai on a green checkered tablecloth" width={1200} height={1008} />
      </div>
      <div className="hero-copy">
        <span className="eyebrow">Welcome to</span>
        <h1>ChaiChip<span>✦</span></h1>
        <h2>Bureau of Completely Unnecessary Standards™</h2>
        <p>An AI-powered inspection authority for things<br className="desktop-break" /> that absolutely do not need inspection.</p>
        <p>Upload a photo of your banana chips, and our AI identifies the shape of each chip — round, oval, broken, suspicious, or why-does-this-exist.</p>
        <p>Upload a photo of your chai, and our AI counts the bubbles on its surface and determines its completely unnecessary Bubble Quality Score™.</p>
        <p>You don't get nutrition advice.<br />You don't get health advice.<br />You don't even get useful advice.</p>
        <p>You simply get scientifically questionable information about your snack and tea.</p>
      </div>
      <div className="hero-scene bureau-scene">
        <p className="scribble bureau-note">Inspecting the irrelevant.<br />For a better tomorrow.<span className="scribble-arrow">↙</span></p>
        <div className="bureau-wrap">
          <img src={bureauArt} alt="Pixel-art ChaiChip government inspection bureau" width={1008} height={1008} />
          <div className="bureau-sign"><b>ChaiChip</b><span>Bureau of Completely<br />Unnecessary Standards™</span></div>
        </div>
      </div>
    </section>
  );
}

type UploadProps = {
  kind: "banana" | "chai";
  onAnalyze: (file: File, preview: string) => void;
  loading: boolean;
  file: File | null;
  preview: string;
  setFile: (file: File | null, preview: string) => void;
};

function ImageUploader({ kind, onAnalyze, loading, file, preview, setFile }: UploadProps) {
  const inputId = useId();
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");
  const choose = (selected?: File) => {
    if (!selected) return;
    if (!(["image/jpeg", "image/png"].includes(selected.type))) {
      setError("Please choose a JPG or PNG image.");
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError("That file is over the official 5 MB limit.");
      return;
    }
    setError("");
    setFile(selected, URL.createObjectURL(selected));
  };
  const remove = () => {
    if (preview) URL.revokeObjectURL(preview);
    if (inputRef.current) inputRef.current.value = "";
    setError("");
    setFile(null, "");
  };
  return (
    <div className="uploader">
      <input ref={inputRef} id={inputId} className="sr-only" type="file" accept=".jpg,.jpeg,.png,image/jpeg,image/png" onChange={(event) => choose(event.target.files?.[0])} />
      {!file ? (
        <label htmlFor={inputId} className="upload-label"><span className="pixel-upload" aria-hidden="true">⇧</span> Upload Image</label>
      ) : (
        <div className="file-preview">
          <img src={preview} alt={`Selected ${kind} inspection`} />
          <div className="file-meta"><strong title={file.name}>{file.name}</strong><small>{(file.size / 1024 / 1024).toFixed(2)} MB · Ready for inspection</small></div>
          <PixelButton tone="plain" onClick={remove}>Remove Image</PixelButton>
        </div>
      )}
      {error && <p className="upload-error" role="alert">{error}</p>}
      <p className="file-help">Supports JPG, JPEG, PNG&nbsp;&nbsp; • &nbsp;&nbsp;Max 5MB</p>
      {file && <PixelButton tone="gold" onClick={() => onAnalyze(file, preview)} disabled={loading} className="analyze-button">{loading ? "Analyzing…" : kind === "banana" ? "Analyze Chip Geometry" : "Count the Bubbles"}</PixelButton>}
    </div>
  );
}

const shapeNames = ["Circularoid", "Elliptic Discus", "Quasi-Circular Lamina", "Radial Ovaloid", "Asymmetric Ellipsoid", "Semi-Arc Fragment", "Irregular Annuloid", "Flattened Orbiform", "Partial Elliptic Segment", "Radial Disc Fragment", "Non-Euclidean Chipform", "Circumferential Irregularity", "Pseudo-Elliptical Form", "Polygonal Curvature Variant", "Near-Circular Food Geometry"];
const observations = ["Geometric confidence: unnecessarily high.", "Curvature appears snack-compatible.", "Classification remains scientifically questionable.", "Further inspection is completely unnecessary."];
const chaiClasses = ["Moderately Bubbly", "Suspiciously Frothy", "Structurally Tea-Like", "Unnecessarily Bubbly", "Acceptably Effervescent", "Foam Distribution: Questionable"];

function randomShapes() {
  const shuffled = [...shapeNames].sort(() => Math.random() - 0.5).slice(0, 6);
  const weights = Array.from({ length: 6 }, () => Math.random() + 0.15);
  const total = weights.reduce((sum, n) => sum + n, 0);
  const values = weights.map((n) => Math.floor((n / total) * 100));
  values[0] += 100 - values.reduce((sum, n) => sum + n, 0);
  return shuffled.map((name, index) => ({ name, value: values[index] }));
}

function AnalysisLoader({ kind }: { kind: "banana" | "chai" }) {
  const messages = kind === "banana" ? ["Calibrating snack geometry...", "Measuring unnecessary curvature...", "Consulting the Bureau..."] : ["Counting chai bubbles...", "Inspecting foam distribution...", "Performing extremely important calculations..."];
  const [message, setMessage] = useState(messages[0]);
  useEffect(() => {
    let index = 0;
    const timer = window.setInterval(() => { index = (index + 1) % messages.length; setMessage(messages[index]); }, 520);
    return () => window.clearInterval(timer);
  }, [kind]);
  return <div className="analysis-loader"><span className="loader-cup">♨</span><b>{message}</b><span className="loading-blocks"><i /><i /><i /><i /><i /></span></div>;
}

function InspectionCard({ kind }: { kind: "banana" | "chai" }) {
  const [file, setFileState] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [loading, setLoading] = useState(false);
  const [bananaResult, setBananaResult] = useState<{ shapes: { name: string; value: number }[]; note: string } | null>(null);
  const [chaiResult, setChaiResult] = useState<{ score: number; bubbles: number; distribution: string; classification: string } | null>(null);
  const setFile = (next: File | null, url: string) => { setFileState(next); setPreview(url); setBananaResult(null); setChaiResult(null); };
  const analyze = async (selected: File) => {
    setLoading(true);
    await new Promise((resolve) => window.setTimeout(resolve, 1500 + Math.random() * 500));
    const thumbnail = await thumbnailFor(selected);
    if (kind === "banana") {
      const shapes = randomShapes();
      const note = observations[Math.floor(Math.random() * observations.length)];
      setBananaResult({ shapes, note });
      saveReport({ id: crypto.randomUUID(), type: "Banana Chip", date: new Date().toISOString(), thumbnail, classification: shapes[0].name, score: `${Math.max(72, Math.floor(Math.random() * 25) + 72)}% geometric confidence`, conclusion: note, details: shapes.slice(0, 4).map((shape) => ({ label: shape.name, value: `${shape.value}%` })) });
    } else {
      const score = Math.floor(Math.random() * 46) + 50;
      const bubbles = Math.floor(Math.random() * 72) + 18;
      const distributions = ["Moderately Uniform", "Radially Questionable", "Acceptably Scattered", "Suspiciously Centralized"];
      const classification = chaiClasses[Math.floor(Math.random() * chaiClasses.length)];
      const distribution = distributions[Math.floor(Math.random() * distributions.length)];
      setChaiResult({ score, bubbles, distribution, classification });
      saveReport({ id: crypto.randomUUID(), type: "Chai", date: new Date().toISOString(), thumbnail, classification, score: `${score}/100 Bubble Quality`, conclusion: "Further investigation is completely unnecessary.", details: [{ label: "Estimated Bubble Count", value: String(bubbles) }, { label: "Distribution", value: distribution }] });
    }
    setLoading(false);
  };

  return (
    <article className={`inspection-card ${kind}`}>
      <div className="inspection-intro">
        <div className="title-row"><span className="title-icon" aria-hidden="true">{kind === "banana" ? "◒" : "♨"}</span><h3>{kind === "banana" ? "Banana Chips Inspection" : "Chai Bubble Analysis"}</h3></div>
        <p>{kind === "banana" ? "Upload a photo of your banana chips and get a detailed shape analysis. Because yes, we can." : "Upload a photo of your chai and let our AI count the bubbles and assign a completely unnecessary Bubble Quality Score™."}</p>
        <ImageUploader kind={kind} file={file} preview={preview} setFile={setFile} loading={loading} onAnalyze={analyze} />
      </div>
      <div className="result-panel">
        {loading ? <AnalysisLoader kind={kind} /> : kind === "banana" && bananaResult ? (
          <div className="shape-result"><h4>Shape Analysis</h4>{bananaResult.shapes.map((shape) => <div className="shape-row" key={shape.name}><span>{shape.name}</span><i /><b>{shape.value}%</b></div>)}<p>✦ {bananaResult.note}</p></div>
        ) : kind === "chai" && chaiResult ? (
          <div className="bubble-result"><h4>Bubble Quality Score™</h4><strong>{chaiResult.score}<small>/100</small></strong><b>{chaiResult.classification}</b><dl><div><dt>Estimated Bubble Count</dt><dd>{chaiResult.bubbles}</dd></div><div><dt>Bubble Distribution</dt><dd>{chaiResult.distribution}</dd></div></dl><p>Further investigation is completely unnecessary.</p></div>
        ) : (
          <div className="awaiting-result"><span>{kind === "banana" ? "◉" : "○○°"}</span><b>{kind === "banana" ? "Awaiting snack geometry" : "Awaiting surface bubbles"}</b><small>Your official findings will appear here.</small></div>
        )}
      </div>
    </article>
  );
}

export function InspectionSection() {
  return <section id="inspect" className="inspection-grid"><InspectionCard kind="banana" /><InspectionCard kind="chai" /></section>;
}

function SpriteIcon({ position }: { position: 0 | 1 | 2 }) {
  return <span className={`sprite-icon sprite-${position}`}><img src={iconSheet} alt="" width={816} height={816} loading="lazy" /></span>;
}

export function HowItWorks() {
  const steps = [
    ["Upload", "Share a photo of your snack or tea."],
    ["AI Analyzes", "Our advanced (and questionable) algorithms get to work."],
    ["Get Your Report", "Receive your detailed, scientifically questionable analysis."],
  ];
  return (
    <section className="how-it-works">
      <div className="how-heading"><h2>✦ How It Works</h2><p>Three simple steps to get the most useless information.</p></div>
      <div className="steps">{steps.map(([title, text], index) => <div className="step" key={title}><span className="step-number">{index + 1}</span><SpriteIcon position={index as 0 | 1 | 2} /><span><b>{title}</b><small>{text}</small></span>{index < 2 && <i className="step-arrow">›</i>}</div>)}</div>
      <div className="mascot-callout"><img src={mascotArt} alt="ChaiChip inspector mascot holding a clipboard" width={816} height={816} loading="lazy" /><span>Because someone has to<br />check, right?</span></div>
    </section>
  );
}

export function PageFrame({ children }: { children: ReactNode }) {
  return <><Navbar /><main>{children}</main><Footer /></>;
}

export function ReportsView() {
  const [reports, setReports] = useState<Report[]>([]);
  useEffect(() => setReports(readReports()), []);
  const clear = () => { window.localStorage.removeItem(REPORTS_KEY); setReports([]); };
  return (
    <PageFrame><section className="inner-page reports-page"><header className="page-heading"><span>ARCHIVE 04-B</span><h1>Inspection Reports</h1><p>Official records of findings nobody requested.</p></header>
      {reports.length === 0 ? <div className="empty-state"><img src={mascotArt} alt="ChaiChip inspector mascot" width={816} height={816} /><h2>No reports filed.</h2><p>The Bureau is unusually quiet. Submit an inspection to create your first permanent-ish record.</p><Link to="/" hash="inspect" className="text-link">Begin an inspection →</Link></div> : <><div className="reports-toolbar"><span>{reports.length} classified {reports.length === 1 ? "report" : "reports"}</span><PixelButton tone="plain" onClick={clear}>Clear archive</PixelButton></div><div className="report-list">{reports.map((report) => <article className="report-card" key={report.id}>{report.thumbnail ? <img src={report.thumbnail} alt={`Uploaded ${report.type.toLowerCase()} inspection`} /> : <div className="report-placeholder">{report.type === "Chai" ? "♨" : "◒"}</div>}<div className="report-content"><span className="report-type">{report.type} Inspection</span><time>{new Date(report.date).toLocaleString()}</time><h2>{report.classification}</h2><strong>{report.score}</strong>{report.details?.map((detail) => <div className="report-detail" key={detail.label}><span>{detail.label}</span><b>{detail.value}</b></div>)}<p>“{report.conclusion}”</p></div><span className="approved-stamp">INSPECTED</span></article>)}</div></>}
    </section></PageFrame>
  );
}

export function AboutView() {
  const departments = [
    ["01", "Department of Snack Geometry", "Maps the edible frontier, one suspicious curve at a time."],
    ["02", "Department of Bubble Measurement", "Counts surface phenomena with unnecessary administrative precision."],
    ["03", "Department of Unnecessary Standards", "Maintains standards whose absence nobody had previously noticed."],
    ["04", "Department of Questionable Scientific Conclusions", "Turns inconclusive evidence into very confident paperwork."],
  ];
  return <PageFrame><section className="inner-page about-page"><header className="page-heading"><span>ESTABLISHED FOR NO CLEAR REASON</span><h1>About the Bureau</h1><p>ChaiChip was established to answer the questions nobody asked about snacks and tea.</p></header><div className="about-feature"><div><h2>Our official mandate</h2><p>We observe. We measure. We classify. Above all, we produce authoritative-sounding conclusions about banana chip curvature and chai foam.</p><blockquote>“No snack too ordinary. No bubble too small. No investigation particularly necessary.”</blockquote></div><div className="bureau-seal"><img src={bureauArt} alt="The pixel-art headquarters of ChaiChip" width={1008} height={1008} /><span>CHC<br /><small>BUREAU HQ</small></span></div></div><h2 className="departments-title">Authorized Departments</h2><div className="departments">{departments.map(([number, title, copy]) => <article key={number}><span>{number}</span><h3>{title}</h3><p>{copy}</p></article>)}</div><div className="official-note"><img src={mascotArt} alt="ChaiChip inspector mascot" width={816} height={816} loading="lazy" /><p><b>Official notice:</b> ChaiChip provides no nutritional, medical, culinary, or otherwise useful advice.</p></div></section></PageFrame>;
}